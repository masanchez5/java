package Main;
/** Tot just aquest text serà la documentació de la classe.
3 * El que estigui escrit s’inclourà directament a l’HTML resultant.
4 * Aquesta és una classe ben documentada.
5 **/
import java.util.Scanner;

import Fases.Fase1;

public class Main {
		/* ENUNCIAT COMPLET DE L'EXERCICI
		 * FASE 1 (3 punts)
		● Crea tres variables string e inicialitzales amb les dades pertinents (nom, cognom1, cognom2).
		● Crea tres variables int e inicialitzales amb les dades pertinents (dia, mes, any).
		● Mostra per pantalla les variables string concatenant-les en aquest ordre (cognom1 + cognom2, + nom).
		● Mostra per pantalla les variables int concatenant-les amb “/” entre cada una d’elles.
		Cada punt val 0,75 punts.
		
		FASE 2 (3 punts)
		Sabent que l’any 1948 es un any de traspàs:
		● Creeu una variable constant amb el valor de l’any (1948).
		● Creeu una variable constant que guardi cada quan hi ha un any de traspàs.
		● Calculeu quants anys de traspàs hi ha entre 1948 i el vostre any de naixement i emmagatzemeu el valor
		resultant en una variable.
		● Mostreu per pantalla el resultat del càlcul.
		Cada punt val 0,75 punts.
		
		FASE 3 (3 punts)
		
		●
		Partint de l’any 1948 heu de fer un bucle for i mostrar els anys de traspàs fins arriba al vostre any
		de naixement. (0,75 punts)
		ATENCIO! Haureu de canviar el tipus de variable de l’any 1948 per poder modificar-la.
		● Creeu una variable bool que sera certa si l’any de naixement és de traspàs o falsa si no ho és.(0,75 punts)
		● En cas de que la variable bool sigui certa, heu de mostrar per consola una frase on ho digui, en cas de ser
		falsa mostrareu la frase pertinent. Creeu dues variables string per guardar les frases. (1,5 punts)
		FASE 4 (1 punt)
		● Creeu una variable on juntareu el nom i els cognoms (tot en una variable) i un altre on juntareu la data
		de naixement separada per “/” (tot en una variable). Mostreu per consola les variables del nom complet,
		la data de naixement i si l’any de naixement es de traspàs o no.
		Exemple de sortida per consola:
		El meu nom és Juan Perez Gonzalez
		Vaig néixer el 01/01/1979
		El meu any de naixement és de traspàs.
		 * 
		 */
	
	
	
	
	
	public  static void main(String[] args) {
		Main prg = new Main();
	    prg.inici();
	}
		    
		    void inici(){
		    	
		    	Scanner lector = new Scanner(System.in);
		    	System.out.println("FASE 1");
		    	System.out.println("------");
		    	Fases.Fase1.Fase1();
		    	System.out.println(" ");
		    	System.out.println(" ");
		    	System.out.println("FASE 2");
		    	System.out.println("------");
		    	Fases.Fase2.Fase2();
		    	System.out.println(" ");
		    	System.out.println(" ");
		    	System.out.println("FASE 3");
		    	System.out.println("------");
		    	Fases.Fase3.Fase3();
		    	System.out.println(" ");
		    	System.out.println(" ");
		    	System.out.println("FASE 4");
		    	System.out.println("------");
		    	Fases.Fase4.Fase4();
	    	}
}
