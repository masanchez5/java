package Fases;

public class Fase3 {
	//CONSTANTS
	static final int TRASPAS=1948;
	static final String SI_TRASPAS=" es any de traspas";
	static final String NO_TRASPAS=" no es any de traspas";
	
	//VARIABLES
	static int i,j;
	static boolean esTraspas=false;
	static int diferencia, naixement=1987;
	public static void Fase3() {
		diferencia= naixement - TRASPAS;
		int[] candidats = new int[diferencia];
		
		for	(i=0; i<candidats.length-1; i++) {
			     	
	        	candidats[i]=naixement;
	        	naixement--;
	        	esTraspas=(candidats[i]%4==0 && (candidats[i]%100!=0 || candidats[i]%400==0));
	        	if (esTraspas) {
	        		System.out.println(candidats[i] +SI_TRASPAS);
	        	}else {
	        		System.out.println(candidats[i] +NO_TRASPAS);
	        	}
		}
		
	}
}
//