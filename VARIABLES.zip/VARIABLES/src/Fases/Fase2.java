package Fases;


public class Fase2 {
	
	
	
	public static  void Fase2() {
		//CONSTANTS	
		 final int TRASPAS=1948;
		 final int INTERVAL=4;
		//VARIABLES
		 int any=2019;
		 int fila,columna;
		 int i=0,j=0,k=0;
		 int diferencia;
		 
		diferencia= any - TRASPAS;
		
		int[] candidats = new int[diferencia+1];
		for	(i=0; k<diferencia+1; i++) {
			candidats[i]=TRASPAS+k;
			k++;
			
		}
		
		for	(i=0; i<candidats.length-1; i++) {
			if ((candidats[i]%INTERVAL==0) && (candidats[i]%100!=0 || candidats[i]%400==0)) {
	        	j++;
	        	
	        }
		}
		System.out.println("Hi ha "+ j + " anys de traspas entre " + any+ " i " +TRASPAS);
	} 
	
}
