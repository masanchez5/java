package Fases;
import java.text.DecimalFormat;

public class Fase1 {
	static String nom="Miguel Angel",cognom1="Sanchez",cognom2="Florido";
	static int dia=5,mes=11,any=2019;
	
	
	public static void Fase1() {
	DecimalFormat formatter = new DecimalFormat("00");
	System.out.println(nom + " " + cognom1 + " "+ cognom2);
	System.out.println((formatter.format (dia)) + "/" + mes + "/" + any);
	} 
}
