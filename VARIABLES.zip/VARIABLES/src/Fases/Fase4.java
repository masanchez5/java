package Fases;
import java.text.DecimalFormat;
public class Fase4 {
	
	//VARIABLES	
	static String nom="Miguel Angel",cognom1="Sanchez",cognom2="Florido";
	static int dia=5,mes=11,any=2019,naixemenet=1987;
	static boolean esTraspas=false;
	
	public static void Fase4() {
		DecimalFormat formatter = new DecimalFormat("00");
		String nomComplet= nom +" "+ cognom1 +" " + cognom2;
		System.out.println("El meu nom �s " + nomComplet);
		System.out.println( "Vaig neixer "+(formatter.format (dia)) + "/" + mes + "/" + any);
		esTraspas=(naixemenet%4==0 && (naixemenet%100!=0 || naixemenet%400==0));
		
		if (esTraspas) {
			System.out.println("el meu any de naixement �s de trasp�s");
		}else {
			System.out.println("el meu any de naixement no �s de trasp�s");
		}
	}
}
	
