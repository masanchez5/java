package com.ITAcademy.restproject;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ITAcademy.restproject.Domains.Employee;
import com.ITAcademy.restproject.Domains.EmployeeRepository;

@Configuration

public class LoadDatabase {

@Bean

CommandLineRunner initDatabase(EmployeeRepository repository) {

return args -> {

System.out.println("Preloading Data to memoryDatabase");

repository.save(new Employee("Bilbo Baggins", "burglar", 1000));

repository.save(new Employee("Frodo Baggins", "thief",2000));

System.out.println("Data loaded");

};

}

//public WebMvcConfigurer corsConfigurer() {
//	return new WebMvcConfigurer() {
//		@Override
//		public void addCorsMappings(CorsRegistry registry) {
//			registry.addMapping("/employees").allowedOrigins("http://localhost:5222  ");
//		}
//	};
//}

}