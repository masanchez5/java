package com.ITAcademy.restproject.Domains;

import java.util.ArrayList;

public enum EnumJobs{
	
	burglar("burglar"),
	thief("thief"),
	knight("knight"),
	witch("witch");
	
	private String value;

	EnumJobs(String value){
		this.value=value;
	}
	
	public String getValue() {
		return value;
	}

	
	
	
	
//	
//	 public ArrayList<String> enumIteration() {
//	       Jobs[] jobs = Jobs.values();
//	       ArrayList<String> stringJob = new ArrayList<String>();
//	       for (Jobs job : jobs) {
//	    	   stringJob.add(job.toString());
//	       }
//	       return stringJob;
//	   }

}