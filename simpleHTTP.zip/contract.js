
//Funcio to show the entire repository
function readRepository() {
    var $answer1=$('#answer1');	
    
    $.ajax({		
		type: 'GET',
		url: 'http://localhost:8080/employees/',
		success: function(reponse) {
            
            $.each(reponse,function(i,item){
                $answer1.append( item.name + " " + item.role +" " + item.salary+"<br>");
                
            });    
        }
                //document.write(JSON.stringify(data))
                //console.log(JSON.stringify(data))
                //Print name with append
				
												
		
		
		
	});
	
};
//Function to show employee according to the id
function readEmployee() {
	var $answer2=$('#answer2');
	var variable1 = document.getElementById("myText").value	
    $.ajax({		
		type: 'GET',
		url: 'http://localhost:8080/employees/' + variable1,
		success: function(data) {
            $answer2.append( data.name + " " + data.role + " "+ data.salary+"<br>");
                
												
		}
		
		
	});
	
};

//Function to insert a new employee to the database
function addEmployee() {
	//var $empId, $empName, $empRole;
    var $answer3=$('#answer3');
    
    var name = document.getElementById("newName").value;
    var role = document.getElementById("newRole").value;
    var salary=0;
    
    
    if (role == ("burglar")) {
       
        salary=1000;
    }else if(role == ("thief")) {
        
        salary=2000;
    }else if(role ==("knight")) {
        
        salary=3000;
    }else if(role == ("witch")) {
       
        salary=4000;
    }
    var newEmp={      
        name,
        role,
        salary
    };


    console.log(newEmp);
    
    $.ajax({		
        type: 'POST',
        contentType:"application/json",
        url: 'http://localhost:8080/employees/',
        data:JSON.stringify(newEmp),
        dataType:'json',
        cache: false,
        timeout: 600000,
		success: function(result) {
            if(result.status=="success"){
                $answer3.append( "succesful " );
            }
            
                //Print name with append
				//$answer.append(data.name);
												
		}
		
		
	});
    
};

//This function check if the input role is valid. All roles are predefined.
//If the role is valid, addEmployee funtion is called.
function checkRole() {
	var role = document.getElementById("newRole").value;
    var roles;
    var ROLES=4;
    var isCorrect="false";

        (function (roles) {
            roles[roles["burglar"] = 0] = "burglar";
            roles[roles["thief"] = 1] = "thief";
            roles[roles["knight"] = 2] = "knight";
            roles[roles["witch"] = 3] = "witch";
        }       )(roles || (roles = {}));


    for (var i = 0; i < ROLES ; i++) {
        if(role == roles[i]){
            isCorrect="true";
        }
    }
    if(isCorrect=="true"){
        addEmployee();
    }else{
        alert("This role is not valid");
    }
    isCorrect=false;

};

//Function to read an input role. When role is found in database,
//readRepository function is called (function overloaded).
function readRole() {
	var role = document.getElementById("roleId").value;
    var roles;
    var ROLES=4;
    var isCorrect="false";
    var i=0;
        (function (roles) {
            roles[roles["burglar"] = 0] = "burglar";
            roles[roles["thief"] = 1] = "thief";
            roles[roles["knight"] = 2] = "knight";
            roles[roles["witch"] = 3] = "witch";
}       )(roles || (roles = {}));

    while(role !=roles[i]){
        role==roles[i];
        i++;
    }
    
    readRepository2(role);

};

//Function to show employee according to the role inserted as parameter.
function readRepository2(role) {
    var $answer6=$('#answer6');	
    
    $.ajax({		
		type: 'GET',
		url: 'http://localhost:8080/employees/',
		success: function(reponse) {
            
            $.each(reponse,function(i,item){
                if(role == item.role){
                $answer6.append( item.name + " " + item.role +" " + item.salary+"<br>");
                }
            });    
        }
                //document.write(JSON.stringify(data))
                //console.log(JSON.stringify(data))
                //Print name with append
				
												
		
		
		
	});
	
};






function updateEmployee() {
	//var $empId, $empName, $empRole;
    var $answer4=$('#answer4');
    var id = document.getElementById("upId").value;
    var name = document.getElementById("upName").value;
    var role = document.getElementById("upRole").value;
    var newEmp={
        id,      
        name,
        role
    };
    console.log(newEmp);
    $.ajax({		
        type: 'PUT',
        contentType:"application/json",
        url: 'http://localhost:8080/employees/'+ id,
        data:JSON.stringify(newEmp),
        dataType:'json',
        cache: false,
        timeout: 600000,
		success: function(result) {
            if(result.status=="success"){
                $answer4.append( "succesful " );
            }
            
                //Print name with append
				//$answer.append(data.name);
												
		}
		
		
	});
	
};
function deleteEmployee() {
	
    var $answer5=$('#answer5');
    var id = document.getElementById("delId").value;
    
    
    
    $.ajax({		
        type: 'DELETE',
        
        url: 'http://localhost:8080/employees/'+ id,
        dataType:'text',
        
        cache: false,
        timeout: 600000,
		success: function(result) {
            
            //$answer5.append( result.toString());
            
               alert('succesfully deleted');
                //$answer5.append( "succesfully delete " );
            
            
                //Print name with append
				//$answer.append(data.name);
												
		}
		
		
	});
	
};