/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coets;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author formacio
 */
public class Propulsor extends Thread {
    private int potenciaMax;
    private int potenciaActual;
    int objectiu;
    boolean accelerar=false;
    boolean frenar= false;
    
    public Propulsor (int potenciaMax, int potenciaActual) {
        
     
        this.potenciaMax = potenciaMax;
        this.potenciaActual=potenciaActual;
                    
    }

    
    
    @Override
    public void run() {
        
        System.out.println("start of thread");
        System.out.println("Potencia actual: " + potenciaActual);
        System.out.println("Potencia maxima: " + potenciaMax);
        System.out.println("----------------");
        System.out.println("Es comença a propulsar fins a la potencia objectiu " + objectiu + " sense superar la potencia maxima de "+ potenciaMax);
       
        
        //Accelera si potencia actual es menor a potencia objectiu
        while((potenciaActual < objectiu) && (potenciaActual < potenciaMax)){
            
            potenciaActual++;
            System.out.println( potenciaActual);
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
            
           
        }
        
        
        
        
        
        //Frena si potencia actual es major a potencia objectiu
        while((potenciaActual > objectiu) && (potenciaActual > 0)){
            
            potenciaActual--; 
           System.out.println( potenciaActual);
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
            
            
        }
        System.out.println("S'ha arribat a la potencia de " + potenciaActual);
        this.potenciaActual=potenciaActual;
                        
        System.out.println("\n"); 
        System.out.println("End of thread");
       
    
    }      
    
    @Override
    public String toString() {
        return "Propulsor{" + potenciaActual + '}';
    }
    
    public int getIntActual() {
        return potenciaActual ;
    }
  
    public int getIntMaxima() {
        return potenciaMax ;
    }
    
     public void setPotenciaActual(int potenciaActual) {
        this.potenciaActual = potenciaActual;
    }

    public void setObjectiu(int objectiu) {
        this.objectiu = objectiu;
    }
    
    //Metodes no utilitzats
    /*public void propulsar (){
        
        System.out.println("Potencia actual" + potenciaActual);
        System.out.println("Es comença a accelerar fins a la potencia objectiu " + objectiu + " sense passar la maxima "+ potenciaMax);
        boolean esTroba=false;
        
        
        while(potenciaActual < objectiu && potenciaActual < potenciaMax){
            potenciaActual++;
            System.out.println(potenciaActual);
           
        }
        
        while(potenciaActual > objectiu){
           potenciaActual--; 
           System.out.println(potenciaActual);
           
        }
        
                            
        System.out.println("\n"); 
        this.potenciaActual=potenciaActual;
        
        /*do{
            System.out.println(potenciaActual); 
           
            if(potenciaActual < objectiu || potenciaActual < potenciaMax){
                potenciaActual++;
                System.out.println(potenciaActual);
                if(potenciaActual == objectiu || potenciaActual==potenciaMax){
                    esTroba=true;
                }
                
            }else if(potenciaActual > objectiu){
                potenciaActual--;
                System.out.println(potenciaActual);
                
                if(potenciaActual == objectiu){
                    esTroba=true;
                }
            }
            
        }while(!esTroba);*/
            //propulsorsObj.
        /*for (int j = 0; j < propulsorsObj.size(); j++) {
          
                       
                         
                        
        }
       
    }*/


    
    
    
        /*List<Integer> potenciesActuals = new ArrayList<Integer>();
        for (int i=0; i < coetArr.size(); i++) {
                    
         System.out.println("Indica la potencia objectiu");
         System.out.println("\n");

        } 
        return potenciesActuals;*/

   

   

    
           
}   
    



   