/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lletresrepetides;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author miguel
 */
public class FASES {
    Scanner lector = new Scanner(System.in);
	String nom;

	int i=0;
	

	public static void main(String[] args) {



	FASES programa = new FASES();
	programa.inici();

	}
    
	
	public void inici() {
            char[]lletres = fase1();		
            List lletres2 = fase2(lletres);
            Map lletres3 = fase3(lletres2);
            List lletres4 = fase4(lletres2);
	}

	public char[] fase1() {
		char lletres[];
                System.out.println ("FASE 1");
                System.out.println ("------");
		System.out.println ("Introdueix el teu nom");
		nom = lector.nextLine();
		
		int j = nom.length();
                lletres =new char[j];
        
		for (i = 0; i < nom.length(); i++) {
			lletres[i] = nom.charAt(i);
		}
	
	
		for (i = 0; i < nom.length(); i++) {	
			System.out.print (lletres[i]);
			System.out.print (" ");
		}
		System.out.println (" ");
		
		return lletres;
	} 
	
	public List<Character> fase2(char[] lletres) {
						
		char a='a';			
		char e='e';		
		char i='i';	
		char o='o';	
		char u='u';
			
            List<Character> lletres2 = new ArrayList<Character>();
            System.out.println ("FASE 2");
            System.out.println ("------");
	    for (char c : lletres) {
	    	lletres2.add(c);
	    }	
			
	   
			
			for(int j = 0; j< lletres2.size(); j++){ //Itera elementos del primer ArrayList
			     
			           if(lletres2.get(j).equals(a) || lletres2.get(j).equals(e) || lletres2.get(j).equals(i) || lletres2.get(j).equals(o)|| lletres2.get(j).equals(u)){
			               System.out.println("VOCAL");
			           }else{
			        	   System.out.println("CONSONANT");
			           }
			    
			}
            System.out.println (" ");
            return lletres2;
	}
        
     
	public Map fase3(List lletres2) {
            HashMap<Character, Integer> fase3 = new HashMap<Character, Integer>();
           
            int comptador=0;
            System.out.println ("FASE 3");
            System.out.println ("------");
            for (int i = 0; i < lletres2.size(); i ++) {
                
                for (int j = 0; j < lletres2.size(); j ++) {
                    if(lletres2.get(i)==lletres2.get(j)){
                        comptador++;
                    };
                
                
                }
                fase3.put((Character) lletres2.get(i), comptador);
                comptador=0;
            
                
            }
                
                fase3.forEach((Character, Integer) -> System.out.println(Character + ":" + Integer));
                
                System.out.println (" ");
                return fase3;
        }
        
        public List<Character> fase4(List lletres2) {
						
		
            List<Character> espai = new ArrayList<Character>();
            List<Character> lletres4 = new ArrayList<Character>();
            List<Character> nomComplet = new ArrayList<Character>();
            System.out.println ("FASE 4");
            System.out.println ("------");
	    System.out.println ("Introdueix el teu cognom");
            String cognom = lector.nextLine();	
            char space=' ';
            

            for (i = 0; i < cognom.length(); i++) {
                lletres4.add(cognom.charAt(i));
            }
           
            nomComplet.addAll(lletres2);
            nomComplet.add(space);
            nomComplet.addAll(lletres4);
            
            
            System.out.println (nomComplet.size());
            for(int i=0;i<nomComplet.size();i++){
                System.out.print(nomComplet.get(i));
            }    
			
            System.out.println (" ");
            return nomComplet;
	}
}
