/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

public class Wheel {
	private String brand;
	double diameter;

	public Wheel(String brand, double diameter) {
		this.brand = brand;
		this.diameter = diameter;
	}
        
        public String toString() {
            return brand+ " " + diameter;
        }
        
         public boolean equals (Object obj){
            if(obj instanceof Wheel){
                Wheel sameWheel=(Wheel)obj;
                
                if(this.diameter==sameWheel.diameter){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
         }
}
