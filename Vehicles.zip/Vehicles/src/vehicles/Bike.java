/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

import java.util.List;

public class Bike extends Vehicle {

	public Bike(String plate, String brand, String color) {
		super(plate, brand, color);
	}
    
       public void addWheels(List<Wheel> frontWheels, List<Wheel> backWheels) throws Exception {
		addWheelBike(frontWheels);
		addWheelBike(backWheels);
	}

	public void addWheelBike(List<Wheel> wheels) throws Exception {
		

		Wheel wheelBike = wheels.get(0);
		

		this.wheels.add(wheelBike);
		
	}
        

}

