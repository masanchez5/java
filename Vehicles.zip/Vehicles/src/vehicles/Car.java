/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

import java.util.List;

public class Car extends Vehicle {

	public Car(String plate, String brand, String color) {
            
		super(plate, brand, color);
                
	}

	public void addWheels(List<Wheel> frontWheels, List<Wheel> backWheels) throws Exception {
		addTwoWheels(frontWheels);
		addTwoWheels(backWheels);
	}

	public void addTwoWheels(List<Wheel> wheels) throws Exception {
                boolean esCorrecte=true;
                double diameterR=0;
                double diameterL=0;
		if (wheels.size() != 2)
			throw new Exception();

		Wheel rightWheel = wheels.get(0);
                diameterR=rightWheel.diameter;
                
		Wheel leftWheel = wheels.get(1);
                diameterL=leftWheel.diameter;
                
		if (!rightWheel.equals(leftWheel))
			throw new Exception();
                
		this.wheels.add(leftWheel);
		this.wheels.add(rightWheel);
                
	}
        
       
            
                   
        }
        
        

