/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
 
/**
 *
 * @author formacio
 */
public class Main {
    Scanner lector = new Scanner(System.in);
    public static void main(String[] args) {
    
    Main prg = new Main();
    prg.fases();
}

    String matricula, marca, color;
    
    String marcaRodes;
    double diametreRodes;
   
 

    
    int numeros;
    int lletres;
   
    int pregunta=-1;
    public void fases(){
          
    //FASE 1
    while(pregunta<0 || pregunta>1){
        System.out.println ("Vols crear cotxe (0) o moto (1)?");
        pregunta=lector.nextInt();
        lector.nextLine();
    }
    
    
    while((lletres!=3 && lletres!= 2) || numeros!=4){
    System.out.println ("Introdueix matricula de 4 numeros i 2 o 3 lletres");
    matricula=lector.nextLine();
    lletres=0;
    numeros=0;
        //Bucle per comptar lletres a matricula
        for (int i = 0; i < matricula.length(); i++) {
        
        if (Character.isLetter(matricula.charAt(i)))
           lletres++;
        }
        
        //Bucle per comptar numeros a matricula
        for (int i = 0; i < matricula.length(); i++) {
            
        if (Character.isDigit(matricula.charAt(i)))
           numeros++;
        }
        System.out.println (numeros);
    }
    
    System.out.println ("Introdueix marca");
    marca=lector.nextLine();
    System.out.println ("Introdueix color");
    color=lector.nextLine();
    
   

           
            
            
    switch(pregunta){
        case 0:
            System.out.println (" ");
            System.out.println ("COTXE");
            System.out.println ("-----");
            Car car1 = new Car(matricula,marca,color);

            System.out.println(car1);
            
            System.out.println ("Introdueix marca de la roda delantera dreta");            
            marcaRodes=Utils.demanarMarca();
            diametreRodes=Utils.demanarDiametre();
            Wheel frontWheelR = new Wheel(marcaRodes,diametreRodes);
             
            System.out.println ("Introdueix marca de la roda delantera esquerra");           
            marcaRodes=Utils.demanarMarca();
            diametreRodes=Utils.demanarDiametre();
            Wheel frontWheelL = new Wheel(marcaRodes,diametreRodes);
            
            System.out.println ("Introdueix marca de la roda trasera dreta");
            marcaRodes=Utils.demanarMarca();
            diametreRodes=Utils.demanarDiametre();
            Wheel backWheelR = new Wheel(marcaRodes,diametreRodes);
            
            System.out.println ("Introdueix marca de la roda trasera esquerra");
            marcaRodes=Utils.demanarMarca();
            diametreRodes=Utils.demanarDiametre();
            Wheel backWheelL = new Wheel(marcaRodes,diametreRodes);
           
            

            List<Wheel> backWheels =new ArrayList<Wheel>();
            List<Wheel> frontWheels =new ArrayList<Wheel>();

            backWheels.add(backWheelR);
            backWheels.add(backWheelL);

            frontWheels.add(frontWheelR);
            frontWheels.add(frontWheelL);
            
            System.out.println (" ");
            System.out.println ("Rodes");
            System.out.println ("----");
            
            System.out.println(frontWheels);
            System.out.println(backWheels);
            
            try {        
                car1.addWheels(frontWheels, backWheels);
            } catch(Exception e) {
            //ExcepciÃ³!
                System.out.println("Error " + e);

            }
            
            break;
        case 1:
            System.out.println (" ");
            System.out.println ("MOTO");
            System.out.println ("----");
            Bike bike1 = new Bike (matricula,marca,color);
            System.out.println(bike1);
            
            
            System.out.println ("Introdueix marca de la roda trasera");            
           
             
            
            
            String marcaRodesT=Utils.demanarMarca();
            double diametreRodesT=Utils.demanarDiametre();
            Wheel backWheel2 = new Wheel(marcaRodesT,diametreRodesT);
            
            System.out.println ("Introdueix marca de la roda delantera");
            String marcaRodesD=Utils.demanarMarca();
            double diametreRodesD=Utils.demanarDiametre();
            Wheel frontWheel2 = new Wheel(marcaRodesD,diametreRodesD);



            List<Wheel> backWheels2 =new ArrayList<Wheel>();
            List<Wheel> frontWheels2 =new ArrayList<Wheel>();

            backWheels2.add(backWheel2);
            

            frontWheels2.add(frontWheel2);
            
            System.out.println (" ");
            System.out.println ("Rodes");
            System.out.println ("----");
            System.out.println(backWheels2);
            System.out.println(frontWheels2);
            try {        
                bike1.addWheels(frontWheels2, backWheels2);
            } catch(Exception e) {
            //ExcepciÃ³!
                System.out.println("Error " + e);

            }
        break;
    }
                               
    
    
    }   
}

