/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

import java.util.Scanner;

/**
 *
 * @author formacio
 */
public  class Utils {
    
    public  static String demanarMarca (){
        Scanner lector = new Scanner(System.in);
        String marcaRodes;
        marcaRodes=lector.nextLine();
        double diametreRodes = 0;

           
            return marcaRodes;
    }
    
    public  static double demanarDiametre (){
        Scanner lector = new Scanner(System.in);
        
        double diametreRodes = 0;

            while(diametreRodes<0.4 || diametreRodes>4 ){
                System.out.println ("Introdueix diametre de les rodes entre 0,4 i 4");
                diametreRodes=lector.nextDouble();
            }
        return diametreRodes;
    }
}
