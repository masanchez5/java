/*
 Exercici:
L’exercici consisteix a mostrar per consola una carta d’un restaurant on afegirem diferents plats i després
escollirem que volem per menjar. Un cop fet això s’haurà de calcular el preu del menjar el programa ens dirà
amb quins bitllets hem de pagar.

FASE 1 (2 punts)
● Creeu una variable int per cada un dels bitllets que existeixen des de 5€ a 500€, haureu de crear un altre
variable per guardar el preu total del menjar. (1 punt)
● Creeu dos arrays, un on guardarem el menú (5 plats) i un altre on guardarem el preu de cada
plat. (1 punt)


FASE 2 (3 punts)
● Amb un bucle for haurem d’omplir els dos arrays anteriorment creats. Afegirem el nom del plat i després
el preu. (1 punt)
● Un cop plens els dos arrays haurem de mostrar-los i preguntar que es vol per menjar, guardarem la
informació en una List fent servir un bucle while. (1 punt)
● Haurem de preguntar si es vol seguir demanant menjar. Podeu fer servir el sistema (1:Si / 0:No), per tant
haureu de crear un altre variable int per guardar la informació. (1 punt)


FASE 3 (5 punts)
● Un cop hem acabat de demanar el menjar, haurem de comparar la llista amb l’array que hem fet al
principi. En el cas que la informació que hem introduït a la List coincideixi amb la del array, haurem de
sumar el preu del producte demanat; en el cas contrari haurem de mostrar un missatge que digui que el
producte que hem demanat no existeix.
 */


package restaurant;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author miguel
 */
public class Fases {
    Scanner lector = new Scanner(System.in);
    //FASE 1
    int billet5=5,billet10=10,bitllet20=20,bitllet50=50,bitllet100=100,
            bitllet200=200,bitllet500=500;
    String plats[]= new String[5];
    int preus[]= new int[5];
    int j=0;
    int i=0;
    public void fases(){
        //FASE 2
        String plat="";
        int pregunta=-1;
        int sumatori=0;
        boolean esTroba=false;
        for (int i = 0; i < plats.length; i++) {
            System.out.println ("Introdueix plat");
            plats[i] = lector.next();
            System.out.println ("Introdueix preu");
            preus[i] = lector.nextInt();
            
        }
        System.out.println ("");
        System.out.println ("MENU");
        System.out.println ("----");
        for (int i = 0; i < plats.length; i++) {
            System.out.print (plats[i] + " "+ preus[i]);
            System.out.println ("");
            
        }
        
        List<String> comanda = new ArrayList<String>();
        while(pregunta!=0){
            System.out.println ("Vols demanar un plat? Si(1),No(0)");
            pregunta=lector.nextInt();
            if(pregunta==1){
                System.out.println ("Digues quin plat vols");
                plat=lector.next();
            
                comanda.add(plat);
            }
            
        }
        /*for(int i = 0; i< comanda.size(); i++){
            System.out.println(comanda.get(i));
			    
        }*/
        //FASE 3
        while(i<comanda.size()){
         
            while(!esTroba && j<plats.length){
                if(comanda.get(i).equals(plats[j])){
                    esTroba=true;
                    sumatori= sumatori + preus[j];
                }
                j++;
            }
            
            if(!esTroba){
                System.out.println ( comanda.get(i) + " no es troba al menu");
            }
            esTroba=false;
            j=0;
            
            i++;
        }
        
        
        System.out.println ("El compte es " + sumatori);
        
    }
    
}
