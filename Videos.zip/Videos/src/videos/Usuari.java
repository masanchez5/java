/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videos;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author formacio
 */
public class Usuari {
    private String nom;
    private String cognom;
    private String password;
    private String data;
    
    
    
    public Usuari(String nom, String cognom,String password,String data) {
		this.nom = nom;
		this.cognom = cognom;
                this.password = password;
                this.data=data;
               
		
    }
    
    /*public List<String> tellName(List<Usuari> usuariArr){
        List<String> nomArr = new ArrayList<String>();
         for (int i = 0; i < usuariArr.size();i++){
             nomArr.set(i)=usuariArr.get(i);
        }   
        return nomArr;
    }*/

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuari other = (Usuari) obj;
        if (!Objects.equals(this.nom, other.nom)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        return true;
    }
    
    public String tellName (){
        
        String tellName=this.nom;
        
        return tellName;
        
    }

    @Override
    public String toString() {
        return "Usuari{" + "nom=" + nom + ", cognom=" + cognom + ", password=" + password + ", data=" + data + '}';
    }

    
    
    

    


    

   
    
    
        
}

