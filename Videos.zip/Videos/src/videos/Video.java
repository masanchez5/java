/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videos;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author formacio
 */
public class Video {
    String URL;
    String titol;
    String usuari;
    List<String> tags = new ArrayList<String>();
    
    public Video(String URL, String titol, List<String> tags,String usuari) {
		this.URL = URL;
		this.titol = titol;
		this.tags = tags;
                this.usuari=usuari;
    }

    @Override
    public String toString() {
        return "Video{" + "URL=" + URL + ", titol=" + titol + ", usuari=" + usuari + ", tags=" + tags + '}';
    }
    
    
    
    
    
    
}
