/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author formacio
 */
public class Videos {
    //CONSTANTS
    static final short OPCIO1=1,OPCIO2=2,OPCIO3=3,OPCIO4=4;
    Scanner lector = new Scanner(System.in);
    
    public static void main(String[] args) {
    
    Videos prg = new Videos();
    prg.inici();
    
    }
    
    
    int i;
    int opcio;
    
    boolean esTroba=false;
    
    String userLogin;
    String nom;
    String cognom;
    String data;
    String loginCorrecte;
    
    String password;
    String userPassword;
    String creador;
    List<String> usuaris = new ArrayList<String>();
   
  
    String URL;
    String titol;  
    String nouTag;
    int numTags;
   
    List<Usuari> usuariArr = new ArrayList<Usuari>();
    List<Video> videoArr = new ArrayList<Video>();
    
    public void inici(){
        
        do{
             opcio=mostrarMenu();
           
            if(opcio==OPCIO1){
                 try {
                     crearUsuari();
                 } catch (Exception ex) {
                    System.out.println("Excepcio: "+ ex + " Has introduit camps buits");
                 }                
            }
            
            if(opcio==OPCIO2){
                 try {
                     crearVideo();
                 } catch (Exception ex) {
                     System.out.println("Excepcio: "+ ex + " Has introduit camps buits");
                 }
            }
            
            if(opcio==OPCIO3){
                 try {
                     ferLogin();
                 } catch (Exception ex) {
                     System.out.println("Excepcio: "+ ex + " Has introduit camps buits");
                 }
            }
            
        }while (opcio!=OPCIO4);
    }
    
        public  int mostrarMenu(){
           
            boolean  esCorrecte=false;
            System.out.println("Tria la opcio desitjada");
            System.out.println("-----------------------");
            System.out.println("1. Afegir usuari");
            System.out.println("2. Afegir video");                
            System.out.println("3. Fer login com usuari i mostrar els seus videos");
            System.out.println("4. Sortir");
            
            do {                         
            esCorrecte = lector.hasNextInt();           
            //El boolea sera cert si s'introdueix nombre enter           
                if (esCorrecte) {
                //Si la dada es un nombre sencer, es guarda a la variable corresponent.
                opcio = lector.nextInt(); 
               
                    //Condicional que controla valors valids de la variable "pregunta".
                    if (opcio <OPCIO1 || opcio>OPCIO4){ 
                        System.out.println("Dada erronia, torna a introduir.");   
                        //Els següents booleans son falsos si el nombre es incorrecte.
                        esCorrecte=false;
                    }

                }
            //lector.nextLine();
            
            //El bucle do-while opera si es compleix que la dada es incorrecta                  
                } while (!esCorrecte);
            //Es retorna el valor de la variable pregunta al programa inici
           
            return opcio;
        }
                                                                                                                                                                                                    
    public void crearUsuari() throws Exception {
        lector.nextLine();
        System.out.println ("Digues el nom d'usuari");
        nom=lector.nextLine();

        System.out.println ("Digues el cognom d'usuari");
        cognom=lector.nextLine();

        System.out.println ("Digues la contrasenya d'usuari");
        password=lector.nextLine();

        System.out.println ("Digues la data de creacio");
        data=lector.nextLine();

        usuariArr.add(new Usuari(nom,cognom,password,data));
        
        if (nom.equals("") || cognom.equals("") || password.equals("") || data.equals("")){
                            throw new Exception();                                          
        }
    }
    
    public void crearVideo() throws Exception {
    
    
        lector.nextLine();
            
           
                while(!esTroba){
                    System.out.println ("Digues el nom de l'usuari que vol pujar el video");
                    creador=lector.nextLine();     
                    
                    System.out.println ("Digues la contrasenya l'usuari que vol pujar el video");
                    password = lector.nextLine();
                    Usuari puja = new Usuari (creador,null,password,data);
                    
                    for (int i = 0; i < usuariArr.size(); i++) {
                    Usuari sameUsuari = usuariArr.get(i);
                    
                    if(puja.equals(sameUsuari)){
                    esTroba=true;
                    }
                    
                }
                if (creador.equals("") || password.equals("")){
                            throw new Exception();                                          
                }
                 
                if(!esTroba){
                    System.out.println ("Usuari introduit erroniament");
                }
                if(esTroba){
                System.out.println ("Digues el titol del nou video");
                titol=lector.nextLine();
                System.out.println ("Digues el URL del nou video");
                URL=lector.nextLine();
                System.out.println ("Digues el nombre de tags que vols introduir");
                numTags=lector.nextInt(); 
                lector.nextLine();
                
                if (titol.equals("") || URL.equals("") || numTags==0 ){
                            throw new Exception();                                          
                }
                
                List<String> tagsVideo = new ArrayList<String>();
                for (int i = 0; i < numTags; i++) {
                    System.out.println ("Digues el tag");
                    nouTag=lector.nextLine();
                    tagsVideo.add(nouTag);
                    if (nouTag.equals("")){
                            throw new Exception();                                          
                }
                }
                
                videoArr.add(new Video( URL,  titol, tagsVideo,creador));
                
                }
                }
                esTroba=false;
                    
            }
            
                
                
               
               
                
                
                                                                                 
        

    public void ferLogin() throws Exception{
       
        lector.nextLine();
            Usuari usuari = new Usuari(null,null,null,null);
            while(!esTroba){
                System.out.println ("Digues el nom de l'usuari amb el que vols fer login");
                userLogin=lector.nextLine();     
                System.out.println ("Digues la contrasenya l'usuari amb el que vols fer login");
                userPassword = lector.nextLine();
                
                if (userLogin.equals("") || userPassword.equals("")){
                            throw new Exception();                                          
                }
                
                Usuari sameUserLogin = new Usuari(userLogin, null, userPassword,null);

                for (i = 0; i < usuariArr.size(); i++) {
                    usuari=(usuariArr.get(i));

                    

                    if(sameUserLogin.equals(usuari)){
                        esTroba=true;

                        loginCorrecte= usuari.tellName();


                    }                  
                }

                if(!esTroba){
                System.out.println ("Usuari o contrasenya introduits erroniament");
                }              

            }
            
            Video video = new Video(null, null, null,null);
            
            for (int i = 0; i < videoArr.size(); i++) {
                video=videoArr.get(i);
                
                
                if ( loginCorrecte.equals(video.usuari)){        
                    System.out.println (video);
                }        
            }
            System.out.println ("");
            loginCorrecte="";
            esTroba=false;  
                
            }
}

