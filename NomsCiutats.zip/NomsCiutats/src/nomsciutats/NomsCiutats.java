/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nomsciutats;

/**
 *
 * @author miguel
 */
public class NomsCiutats {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
	NomsCiutats programa = new NomsCiutats();
	programa.inici();
    }
    
    public void inici() {
        Fases fases = new Fases();
        fases.fases();
        
    }
    
    
}
