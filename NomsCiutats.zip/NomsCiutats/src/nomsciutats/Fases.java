/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nomsciutats;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author miguel
 */
public class Fases {
    String ciutat1="";
    String ciutat2="";
    String ciutat3="";
    String ciutat4="";
    String ciutat5="";
    String ciutat6="";
    
    Scanner lector = new Scanner(System.in);
    
    public void fases(){
        //FASE 1
        System.out.println ("FASE 1 ");
        System.out.println ("------");
        System.out.println ("Introdueix el teu nom de la ciutat 1");
        ciutat1 = lector.nextLine();
        System.out.println ("Introdueix el teu nom de la ciutat 2");
        ciutat2 = lector.nextLine();
        System.out.println ("Introdueix el teu nom de la ciutat 3");
        ciutat3 = lector.nextLine();
        System.out.println ("Introdueix el teu nom de la ciutat 4");
        ciutat4 = lector.nextLine();
        System.out.println ("Introdueix el teu nom de la ciutat 5");
        ciutat5 = lector.nextLine();
        System.out.println ("Introdueix el teu nom de la ciutat 6");
        ciutat6 = lector.nextLine();


        System.out.println (ciutat1 +" "+ ciutat2 +" "+ ciutat3 +" "
                + ciutat4+" " + ciutat5+" " + ciutat6);

        //FASE 2
        System.out.println ("FASE 2 ");
        System.out.println ("------");
        String arrayCiutats[]= new String[6];
        arrayCiutats[0]=ciutat1;
        arrayCiutats[1]=ciutat2;
        arrayCiutats[2]=ciutat3;
        arrayCiutats[3]=ciutat4;
        arrayCiutats[4]=ciutat5;
        arrayCiutats[5]=ciutat6;
        String ciutatAux="";



        for (int i = 0; i < arrayCiutats.length-1; i++) {


            for (int j = i + 1; j < arrayCiutats.length; j++) {



                if (arrayCiutats[i].compareTo(arrayCiutats[j])>0){
                    ciutatAux=arrayCiutats[i];
                    arrayCiutats[i]=arrayCiutats[j];
                    arrayCiutats[j]=ciutatAux;

                }

            }

        }
        //Metode implintat a la lliberia de Java:
        //Arrays.sort(arrayCiutats);


        for (int i = 0; i < arrayCiutats.length; i++) {
            System.out.print (arrayCiutats[i]+ " ");
        }

        System.out.println (" ");

        //FASE 3
        String ArrayCiutatsModificades[]= new String[6];
        String canvi="";
        System.out.println ("FASE 3 ");
        System.out.println ("------");
        for(int i=0; i< ArrayCiutatsModificades.length; i++){



            //Es canvia les vocals pel nombre 4 i es guarda al nou array.
            ArrayCiutatsModificades[i]=arrayCiutats[i].replace('a','4');

            System.out.println(ArrayCiutatsModificades[i]);
        }

        //FASE 4
        System.out.println ("FASE 4");
        System.out.println ("------");
        char lletres1[] = new char[ciutat1.length()];
        char lletres2[]= new char[ciutat2.length()];
        char lletres3[]= new char[ciutat3.length()];
        char lletres4[]= new char[ciutat4.length()];
        char lletres5[]= new char[ciutat5.length()];
        char lletres6[]= new char[ciutat6.length()];
        int j=0;

        // Enter j te el valor maxim de l'array de lletres.
        j=lletres1.length-1;
        for (int i = 0; i < lletres1.length; i++) {
            //A la posicio 1 es guarda l'ultim caracter de la ciutat,
            //al tenir j el valor maxim de l'array.
            lletres1[i] = ciutat1.charAt(j);
            System.out.print (lletres1[i] + " ");
            //Es decrementa j una posicio per continuar escrivint la ciutat a la inversa.
            j--;

        }
        System.out.println (" ");
        j=lletres2.length-1;
        for (int i = 0; i < lletres2.length; i++) {
            lletres2[i] = ciutat2.charAt(j);
            System.out.print (lletres2[i]+ " ");
            j--;

        }
        System.out.println (" ");
        j=lletres3.length-1;
        for (int i = 0; i < lletres3.length; i++) {
            lletres3[i] = ciutat3.charAt(j);
            System.out.print (lletres3[i]+ " ");
            j--;
        }
        j=lletres4.length-1;
        System.out.println (" ");
        for (int i = 0; i < lletres4.length; i++) {
            lletres4[i] = ciutat4.charAt(j);
            System.out.print (lletres4[i]+ " ");
            j--;
        }
        System.out.println (" ");
        j=lletres5.length-1;
        for (int i = 0; i < lletres5.length; i++) {
            lletres5[i] = ciutat5.charAt(j);
            System.out.print (lletres5[i]+ " ");
            j--;
        }
        System.out.println (" ");
        j=lletres6.length-1;
        for (int i = 0; i < lletres6.length; i++) {
            lletres6[i] = ciutat6.charAt(j);
            System.out.print (lletres6[i]+ " ");
            j--;
        }


    }
    
}
