package com.ITAcademy.restproject.Repositories;

import java.awt.print.Pageable;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.ITAcademy.restproject.Domains.Shop;

@Repository
public interface ShopRepository extends JpaRepository<Shop, Long> {

	//Page<Shop> findAll(Pageable pageable);
	

}