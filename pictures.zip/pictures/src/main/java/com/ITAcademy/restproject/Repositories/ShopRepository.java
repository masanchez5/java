package com.ITAcademy.restproject.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ITAcademy.restproject.Domains.Shop;

public interface ShopRepository extends JpaRepository<Shop, Long> {
	

}