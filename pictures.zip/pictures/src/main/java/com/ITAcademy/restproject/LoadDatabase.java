package com.ITAcademy.restproject;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.ITAcademy.restproject.Domains.Shop;
import com.ITAcademy.restproject.Repositories.ShopRepository;



@Configuration

public class LoadDatabase {

@Bean

CommandLineRunner initDatabase(ShopRepository repository) {

return args -> {

System.out.println("Preloading Data to memoryDatabase");

repository.save(new Shop("Ultimate Grow Shop", 10));

repository.save(new Shop("Infinite Cocaine",20));

System.out.println("Data loaded");

};

}

//public WebMvcConfigurer corsConfigurer() {
//	return new WebMvcConfigurer() {
//		@Override
//		public void addCorsMappings(CorsRegistry registry) {
//			registry.addMapping("/employees").allowedOrigins("http://localhost:5222  ");
//		}
//	};
//}

}