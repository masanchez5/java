package com.ITAcademy.restproject.Controllers;

import com.ITAcademy.restproject.Domains.ResourceNotFoundException;

import java.util.Iterator;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ITAcademy.restproject.Domains.Shop;
import com.ITAcademy.restproject.Domains.ShopNotFoundException;
import com.ITAcademy.restproject.Repositories.ShopRepository;


@RestController
//@RequestMapping("/api")

public class ShopController {
	
@Autowired
private  ShopRepository shopRepository;


//public ShopController(){
//	
//}

//ShopController(ShopRepository repository) {
////
//this.shopRepository = repository;
////
//}



//List<Shop> all() {
//
//return repository.findAll();
//
//}

@GetMapping("/shops")
	List<Shop> getAllShops() {
    return  shopRepository.findAll();
}

//Post request to add shops

@PostMapping("/shops")

//Shop newShop(@RequestBody Shop newShop) {
//
//return shopRepository.save(newShop);
//
//}
public Shop createShop(@Valid @RequestBody Shop shop) {
	boolean isFound=false;
	List <Shop> checkShop = getAllShops();
	
	//foreach loop to check if the new shop is already in the repository
	for (Shop shop2 : checkShop) {
		if (shop.getName().equals(shop2.getName())) {
			isFound=true;
			String name="This shop is already set up";
			shop.setName(name);		
						
		}
	}	
	//if the new shop is found, the object returned will alert this in its name.
	if (isFound) {
		return shop;
	}else{
		return shopRepository.save(shop);
	}
	
}


// Single item

@GetMapping("/shops/{id}")
Shop one(@PathVariable Long id) {
//
return shopRepository.findById(id)

.orElseThrow(() -> new ShopNotFoundException(id));
//
//}

}
}



//Controller 3. Controller to update data used in the previous exercise.

//@PutMapping("/employees/{id}")
//
//Shop replaceShop(@RequestBody Employee newEmployee, @PathVariable Long id) {
//
//return repository.findById(id)
//
//.map(employee -> {
//
//employee.setName(newEmployee.getName());
//
//employee.setRole(newEmployee.getRole());
//
//return repository.save(employee);
//
//})
//
//.orElseGet(() -> {
//
//newEmployee.setId(id);
//
//return repository.save(newEmployee);
//
//});
//
//}





