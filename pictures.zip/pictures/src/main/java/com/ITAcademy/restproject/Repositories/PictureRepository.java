package com.ITAcademy.restproject.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ITAcademy.restproject.Domains.Picture;

public interface PictureRepository extends JpaRepository<Picture, Long> {
	

}