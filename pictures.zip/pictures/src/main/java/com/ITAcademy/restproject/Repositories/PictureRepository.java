package com.ITAcademy.restproject.Repositories;


import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ITAcademy.restproject.Domains.Picture;

@Repository
public interface PictureRepository extends JpaRepository<Picture, Long> {
	 List<Picture> findByShopId(Long shopId);
	    Optional<Picture> findByIdAndShopId(Long id, Long shopId);
	    
	    

}