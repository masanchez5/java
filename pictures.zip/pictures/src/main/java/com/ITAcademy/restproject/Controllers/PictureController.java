package com.ITAcademy.restproject.Controllers;


import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ITAcademy.restproject.Domains.Picture;
import com.ITAcademy.restproject.Domains.Shop;
import com.ITAcademy.restproject.Domains.ShopNotFoundException;
import com.ITAcademy.restproject.Repositories.PictureRepository;
import com.ITAcademy.restproject.Repositories.ShopRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import com.ITAcademy.restproject.Domains.ResourceNotFoundException;
import com.ITAcademy.restproject.Controllers.ShopController;

@RestController
public class PictureController {
	
	@Autowired
	private  ShopRepository shopRepository;
	 
	@Autowired
	private   PictureRepository picRepository;
	
	
//	public PictureController(){
//		
//	}
//	PictureController(@PathVariable("id") Long repositoryPic) {
//
//	this.picRepository = (PictureRepository) repositoryPic;
//
//	}
	
	
	
	
//	List<Picture> all() {
//
//		return repositoryPic.findAll();
//
//		}

	@GetMapping("/shops/{shopId}/pictures")
	public List<Picture> getAllPicturesByShopId(@PathVariable (value = "shopId") Long shopId) {
		return picRepository.findByShopId(shopId);
	}

		//Post request to add pictures

		

//		Picture newPicture(@RequestBody Picture newPicture) {
//
//		return repositoryPic.save(newPicture);
//
//		}
		@PostMapping("/shops/{shopId}/pictures")
		public  Picture createPicture(@PathVariable (value = "shopId") Long shopId, @Valid @RequestBody Picture picture) {
			
			boolean isPossible=false;
			isPossible = checkCapacity(shopId);
			if(isPossible) {
			return shopRepository.findById(shopId).map(shop -> {
			picture.setShop(shop);
			return picRepository.save(picture);
			}).orElseThrow(() -> new ResourceNotFoundException("ShopId " + shopId + " not found"));
			}else {
				return null;
			}
		}
		
		public boolean checkCapacity(Long shopId) {
			boolean isPossible=false;
			List<Picture> pictures = picRepository.findByShopId(shopId);
			Shop shop = shopRepository.findById(shopId)
			.orElseThrow(() -> new ShopNotFoundException(shopId));
			if(pictures.size()< (shop.getCapacity())) {
				isPossible=true;
			}
			return isPossible;
		}

		
		@DeleteMapping("/shops/{shopId}/pictures/{picId}")
	    public ResponseEntity<?> deletePicture(@PathVariable (value = "shopId") Long shopId,
	                              @PathVariable (value = "picId") Long picId) {
	        return picRepository.findByIdAndShopId(picId, shopId).map(Picture -> {
	            picRepository.delete(Picture);
	            return ResponseEntity.ok().build();
	        }).orElseThrow(() -> new ResourceNotFoundException("Picture not found with id " + picId + " and shopId " + shopId));
	    }
		
//		@DeleteMapping("/shops/{shopId}/{picId}")
//		public ResponseEntity<Object> deletePicture(@PathVariable Long shopId, @PathVariable Long picId) {
//		    
//			
//				service.deleteById(picId);
//			
//			
//		    return ResponseEntity.noContent().build();
//		}
//		// Single item
//
//		@GetMapping("/pictures/{id}")
//
//		Picture one(@PathVariable Long id) {
//
//		return picRepository.findById(id)
//
//		.orElseThrow(() -> new ShopNotFoundException(id));
//
//		}





		//Controller 3. Controller to update data used in the previous exercise.

		//@PutMapping("/employees/{id}")
		//
		//Shop replaceShop(@RequestBody Employee newEmployee, @PathVariable Long id) {
		//
		//return repository.findById(id)
		//
		//.map(employee -> {
		//
		//employee.setName(newEmployee.getName());
		//
		//employee.setRole(newEmployee.getRole());
		//
		//return repository.save(employee);
		//
		//})
		//
		//.orElseGet(() -> {
		//
		//newEmployee.setId(id);
		//
		//return repository.save(newEmployee);
		//
		//});
		//
		//}



	
}
