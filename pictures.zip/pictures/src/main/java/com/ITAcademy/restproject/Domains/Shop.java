package com.ITAcademy.restproject.Domains;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.ITAcademy.restproject.Repositories.PictureRepository;
import com.ITAcademy.restproject.Repositories.ShopRepository;

@Entity
public class Shop {
	private @Id @GeneratedValue Long id;
	
	
	private String name;
	private int capacity;	
	//private List<Picture> pictures = new ArrayList<Picture>();
	//private final PictureRepository repository;
	
	public Shop() {
		
		
		
		
	}

	public Shop(String name, int capacity) {
									
					
					
					
					this.name = name;
					this.capacity = capacity;
					
				
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}




}
