package com.ITAcademy.restproject.Domains;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.ITAcademy.restproject.Domains.Picture;



@Entity
@Table(name = "Shop")
public class Shop{
	private @Id @GeneratedValue Long id;
	
	@NotNull
	@Column(unique = true)
	private String name;
	
	@NotNull
	private int capacity;
 	
	//private List<Picture> pictures = new ArrayList<Picture>();
	//private final PictureRepository repository;
	
	public Shop() {
								
	}

	public Shop(@NotNull String name, @NotNull int capacity) {
																								
					this.name = name;
					this.capacity = capacity;
									
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

//	public List<Picture> getPictures() {
//		return pictures;
//	}
//
//	public void setPictures(List<Picture> pictures) {
//		this.pictures = pictures;
//	}


	

}
