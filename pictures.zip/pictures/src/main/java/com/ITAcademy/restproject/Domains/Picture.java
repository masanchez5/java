package com.ITAcademy.restproject.Domains;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.ITAcademy.restproject.Domains.Shop;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name= "Picture")
public class Picture {
	private @Id @GeneratedValue Long id;
	
	@NotNull
    @Size(max = 100)
    //@Column(unique = true)
    private String name;

	@NotNull
    @Size(max = 250)
	private String author;
	
	
	public Picture() {
	
	}
	
	public Picture(@NotNull String name ,@NotNull String author) {
		
		this.name=name;
		this.author=author;
	}
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "shopId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Shop shop;
	
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}

	
	
	
	
	
}
