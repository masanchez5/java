
//Function to show the entire repository
function readRepository() {
    var $answer1=$('#answer1');

    $.ajax({
		type: 'GET',
        url: 'http://localhost:8080/shops/',

		success: function(reponse) {

            $.each(reponse,function(_i,item){
                $answer1.append( item.name + " " + item.capacity + " "+"<br>");

            });
        }
                //document.write(JSON.stringify(data))
                //console.log(JSON.stringify(data))
                //Print name with append

	});

};

//Function to show shop according to the id
function readShop() {
	var $answer2=$('#answer2');
	var variable1 = document.getElementById("myText").value
    $.ajax({
		type: 'GET',
		url: 'http://localhost:8080/shops/' + variable1,
		success: function(data) {
            $answer2.append( data.name + " " + data.capacity +"<br>");


		}


	});

};

//Function to show the entire repository of a shop
function readPicture() {
    var $answer6=$('#answer6');
    var myShop = document.getElementById("readShop").value;
    $.ajax({
		type: 'GET',
        url: 'http://localhost:8080/shops/'+ myShop + "/pictures",

		success: function(reponse3) {

            $.each(reponse3,function(_i,item){
                $answer6.append( "id: "+ item.id + " name: " + item.name + " author: "+ item.author + "<br>");

            });
        }
                //document.write(JSON.stringify(data))
                //console.log(JSON.stringify(data))
                //Print name with append

	});

};

//Function to insert a new employee to the database
function addShop() {
	//var $empId, $empName, $empRole;
    var $answer3=$('#answer3');

    var name = document.getElementById("newName").value;
    var capacity = document.getElementById("newCap").value;


    var newShop={
        name,
        capacity,

    };

    console.log(newShop);
    //if condicional to check empty values
    if ($.trim($("#newName, #newCap").val()) === "") {
      alert('you did not fill out one of the fields');
    }else{
    $.ajax({
        type: 'POST',
        contentType:"application/json",
        url: 'http://localhost:8080/shops/',
        data:JSON.stringify(newShop),
        dataType:'json',
        cache: false,
        timeout: 600000,
        error: function (_xhr, _ajaxOptions, thrownError) {
          //alert(xhr.responseText);
          alert("Error: "+thrownError);
        },
        success: function(data) {
            if(data.name=="This shop is already set up"){
                $answer3.append( "error " );
            //}
                //Print name with append
				//$answer.append(data.name);
            }else{
              $answer3.append( "successful " );
            }
        }
     });
   }
};


//Function to add picture. It checks empty values and search the name of the input
//shop in the repository.
function addPicture() {
    var shop = document.getElementById("shop").value;

    var $answer4=$('#answer4');
    var name = document.getElementById("newPic").value;
    var author = document.getElementById("newAuth").value;

    var newPic={
        name,
        author,
    };

    var isFound=false;
    var theShop = searchShop(shop);
    var isShop=true;
    if(theShop==null){
        alert("Shop not found");
        var isShop=false;
    }
    if(isShop=true){
        isFound = checkPicture(newPic,theShop);
    }
    
    if(isFound==false){
        if ($.trim($("#newPic, #newAuth").val()) === "") {
            alert('you did not fill out one of the fields');
        }else{  
            
            
            $.ajax({
                type: 'POST',
                contentType:"application/json",
                url: 'http://localhost:8080/shops/'+ theShop +'/pictures',
                data:JSON.stringify(newPic),
                dataType:'json',
                cache: false,
                timeout: 600000,
                success: function(response6) {
                   
                        $answer4.append( "succesful " );
                        console.log(newPic);
                 
                    //}

                        

                },

                error: function (_xhr, _ajaxOptions, _thrownError) {
                    //alert(xhr.responseText);
                    alert("Error: Shop already at maximum capacity ");
                },
            });
        }   
                    
    }else if (isFound==true){
        alert("This picture is already at the shop repository")
    }
                    
           
};
  
  
//Function to check if the picture is in the picture repository
function checkPicture(newPic,theShop){
    var isFound=false;
    
                    $.ajax({
                        async: false,
                        type: 'GET',
                        url: 'http://localhost:8080/shops/' + theShop + "/pictures",
                        success: function(list_regions) {
                            $.each(list_regions,function(_i,value){
                                if(value.name==newPic.name){
                                    isFound=true;
                                }
                            });
                           
                        }
                    });  
                
            
        
     
    return isFound;
};

function searchShop(searching){
    var thisShop=0;
    var isShop=false;
    $.ajax({
        async: false,
        type: 'GET',
        url: 'http://localhost:8080/shops/',
        success: function(response) {          
            $.each(response,function(_i,item){
                if(searching == item.name){
                    isShop=true;
                    thisShop=item.id;
                }
            });
            
        }
    
    });
    if (isShop==true){
        return thisShop;
    }else if (isShop==false){
        return null;
    }

    
};

function deletePicture() {

    var $answer5=$('#answer5');
    var id = document.getElementById("delShopId").value;

    $.ajax({
    type: 'GET',
    url: 'http://localhost:8080/shops/'+ id + '/pictures',
    success: function(response2) {

                $.each(response2,function(_i,item){


                  $.ajax({
                    type: 'DELETE',

                    url: 'http://localhost:8080/shops/'+ id +'/pictures/'+ item.id,
                    dataType:'text',

                    cache: false,
                    timeout: 600000,
                    success: function(_result) {

                

                    alert('succesfully burned');
                


                

		              }
                });
              });
	        }
       });
 };

