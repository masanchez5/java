
//Funcio to show the entire repository
function readRepository() {
    var $answer1=$('#answer1');

    $.ajax({
		type: 'GET',
		url: 'http://localhost:8080/shops/',
		success: function(reponse) {

            $.each(reponse,function(i,item){
                $answer1.append( item.name + " " + item.capacity +" "+"<br>");

            });
        }
                //document.write(JSON.stringify(data))
                //console.log(JSON.stringify(data))
                //Print name with append

	});

};
//Function to show employee according to the id
function readShop() {
	var $answer2=$('#answer2');
	var variable1 = document.getElementById("myText").value
    $.ajax({
		type: 'GET',
		url: 'http://localhost:8080/shops/' + variable1,
		success: function(data) {
            $answer2.append( data.name + " " + data.capacity +"<br>");


		}


	});

};

//Function to insert a new employee to the database
function addShop() {
	//var $empId, $empName, $empRole;
    var $answer3=$('#answer3');

    var name = document.getElementById("newName").value;
    var capacity = document.getElementById("newCap").value;


    var newShop={
        name,
        capacity,

    };
    console.log(newShop);

    $.ajax({
        type: 'POST',
        contentType:"application/json",
        url: 'http://localhost:8080/shops/',
        data:JSON.stringify(newShop),
        dataType:'json',
        cache: false,
        timeout: 600000,
		success: function(result) {
            if(result.status=="success"){
                $answer3.append( "succesful " );
            }
                //Print name with append
				//$answer.append(data.name);
		}
	});
};

function addPicture() {
	//var $empId, $empName, $empRole;
    var $answer3=$('#answer3');
    var shop = document.getElementById("shop").value;
    var name = document.getElementById("newName").value;
    var author = document.getElementById("newCap").value;

    var newPic={
        name,
        author,
    };

    console.log(newPic);

    $.ajax({
        type: 'POST',
        contentType:"application/json",
        url: 'http://localhost:8080/shops/'+ shop,
        data:JSON.stringify(newPic),
        dataType:'json',
        cache: false,
        timeout: 600000,
		success: function(result) {
            if(result.status=="success"){
                $answer3.append( "succesful " );
            }

                //Print name with append
				//$answer.append(data.name);

		}


	});

};

//Function to read an input role. When role is found in database,
//readRepository function is called (function overloaded).
function readName() {
	var shop = document.getElementById("shop").value;

  var $answer3=$('#answer3');
  var name = document.getElementById("newName").value;
  var author = document.getElementById("newCap").value;

  var newPic={
      name,
      author,
  };

  $.ajax({
  type: 'GET',
  url: 'http://localhost:8080/shops/',
  success: function(reponse) {

          $.each(reponse,function(i,item){
              if(shop == item.name){
                $.ajax({
                    type: 'POST',
                    contentType:"application/json",
                    url: 'http://localhost:8080/shops/'+ item.id,
                    data:JSON.stringify(newPic),
                    dataType:'json',
                    cache: false,
                    timeout: 600000,
          		      success: function(result) {
                        if(result.status=="success"){
                            $answer3.append( "succesful " );
                        }

                            //Print name with append
            				//$answer.append(data.name);

            		}


            	});
              }
          });
  }
              //document.write(JSON.stringify(data))
              //console.log(JSON.stringify(data))
              //Print name with append
});

};

//Function to show employee according to the role inserted as parameter.
