select * from chistes;
SELECT * FROM chistes ORDER BY RAND() LIMIT 1;

ALTER TABLE chistes ADD COLUMN puntuacion INT NOT NULL DEFAULT 10;

SELECT * FROM chistes ORDER BY RAND() LIMIT 1;