
 <?php

/* echo '<p>Hello World</p>';

$nom = "Miguel";

$login = "Mike";

echo "Me llamo ".$nom." AKA ".$login;
*/

/*$array = array(1,2,3,4);
$cadena_texto = implode (" ·· ", $array);

echo $cadena_texto;
$mi_texto = "hola,me llamo, mr x";
$array_texto = explode (",", $mi_texto);
echo $array_texto[2];*/

/*$edad = 99;

if ($edad>= 18) echo "Soy mayor de edad";
else echo "Soy menor";*/

/*$cadena_texto = "Me llamo Jake";

$bodytag = str_replace ("Jake", "Ismael",$cadena_texto);S
echo $bodytag;*/

$mis_profes = array("jake","ismael","jose","ruben");

for($i=0; $i <count($mis_profes);$i++){
  echo ($i+1)." ".$mis_profes[$i].'<br>';
}

echo("<br>");

foreach($mis_profes as $profe){
  echo $profe."<br>";
}

?>
