<?php
//echo "hola mundo ";

include("_db.php");


$sql = "SELECT *
		FROM chistes
		ORDER BY rand()
		LIMIT 1";

$result = $mysqli->query($sql);
$numrows = $result->num_rows;












?>