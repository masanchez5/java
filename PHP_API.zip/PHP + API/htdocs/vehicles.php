<?php 
// Conectarse a y seleccionar una base de datos de MySQL llamada mi_empresa
// Nombre de host: 127.0.0.1, nombre de usuario: tu_usuario, contraseña: tu_contraseña, bd: mi_empresa
$mysqli = new mysqli('127.0.0.1', 'root', '', 'mi_empresa1');

if ($mysqli->connect_errno) {
    echo "Lo sentimos, este sitio web está experimentando problemas.";
    echo "Error: Fallo al conectarse a MySQL debido a: \n";
    echo "Errno: " . $mysqli->connect_errno . "\n";
    echo "Error: " . $mysqli->connect_error . "\n";
    exit;
}
$mysqli->set_charset("utf8");
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Listado vehículos</title>

    <!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
	<div class="container">
		<div class="row">
			<div class="col-md-12"><h1>Los vehículos de nuestra base de datos</h1></div>
			<!-- creamos una variable llamada $sql y almacenamos la petición";-->
			<?php $sql = "SELECT * FROM vehicles";
			// Contectamos la sql con nuestra base de datos
			if ($resultado = mysqli_query($mysqli, $sql)) {
				//realizamos un bucle de nuestra tabla de vehiculos (si tiene 3 registros, se ejecutara 3 veces)
				while ($columnas = mysqli_fetch_assoc($resultado)) {?>
				
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading"><b><a href="#"><?php echo $columnas['marca']." ".$columnas['model']; ?></a></b></div>
							<div class="panel-body">
								<div class="col-md-6">
									<a href="#" class="thumbnail"><img class="img-responsive" src="<?php echo $columnas['url_foto']; ?>" alt=""></a>
								</div>   
								<div class="col-md-6">
									<h4>Características:</h4>
									<p><?php echo $columnas['descripcio']; ?></p>
									<p><span class="glyphicon glyphicon-dashboard"></span> Potencia: <?php echo $columnas['cv']; ?></p>
									<p><span class="glyphicon glyphicon-tags"></span> Año: <?php echo $columnas['any']; ?></p>
								</div>
							</div>                  
						<div class="panel-footer">
							<span class="glyphicon glyphicon-user"></span> <a href="#"><?php echo $columnas['places']; ?> plazas</a> | 
							<a href="#"><span class="label label-info">Ver precio</span></a>
						</div>
					</div>
				</div>
				<?php } 		
			}else echo "Error"; ?>
		</div>
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>